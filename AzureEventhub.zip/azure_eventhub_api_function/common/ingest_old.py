"""Main file to ingest data into Chronicle."""

import json
import os
import sys
from typing import Any, Optional, Sequence

from google.auth.transport import requests as Requests
from google.oauth2 import service_account

from .utils import get_env_var

AUTHORIZATION_SCOPES = ["https://www.googleapis.com/auth/malachite-ingestion"]
CUSTOMER_ID = get_env_var("CHRONICLE_CUSTOMER_ID")
REGION = get_env_var("CHRONICLE_REGION", required=False, default="us")
SERVICE_ACCOUNT = get_env_var("CHRONICLE_SERVICE_ACCOUNT", is_secret=True)

try:
    SERVICE_ACCOUNT_DICT = json.loads(SERVICE_ACCOUNT)
except json.JSONDecodeError as error:
    raise RuntimeError("Invalid Service Account JSON provided.") from error


def initialize_http_session(
        service_account_json: dict[Any, Any],
        scopes: Optional[Sequence[str]] = None,
) -> Requests.AuthorizedSession:
    """Initializes an authenticated session.

    Args:
        service_account_json (dict): Service Account JSON.
        scopes (Optional[Sequence[str]], optional): Required scopes. Defaults to
            None.

    Returns:
        Requests.AuthorizedSession: Authorized session object.
    """
    credentials = service_account.Credentials.from_service_account_info(
        service_account_json,
        scopes=scopes or AUTHORIZATION_SCOPES,
    )
    return Requests.AuthorizedSession(credentials)


def ingest(data: list[Any], log_type: str):
    """ingest with chunk size 1MB to send data to chronicle.

    Args:
        data (list[Any]): raw logs of 3P API.
        log_type (str): data_label of the resource.
    """
    http_session = initialize_http_session(
        SERVICE_ACCOUNT_DICT, scopes=AUTHORIZATION_SCOPES)

    index = 0
    namespace = os.getenv("CHRONICLE_NAMESPACE")
    parsed_data = list(map(lambda i: {"logText": str(json.dumps(i).encode("utf-8"), "utf-8")}, data))
    body = {
        "customerId": CUSTOMER_ID,
        "logType": log_type,
        "entries": [],
    }
    if namespace:
        body["namespace"] = namespace
    while index < len(parsed_data):
        # Create log partitions with a size of 0.95 MB to push data into the Chronicle.
        # For each 100 blocks of data, we will check the size and, if it is less than
        # 0.95MB, add the log entries; otherwise, we will ingest the data into Chronicle.
        if sys.getsizeof(json.dumps(parsed_data[index:index + 100])) >= 950000:
            if sys.getsizeof(json.dumps(parsed_data[index])) + sys.getsizeof(
                    json.dumps(body['entries'])) <= 950000:
                body['entries'].append(parsed_data[index])
                index += 1
            else:
                _send_logs_to_chronicle(
                    http_session,
                    body,
                    REGION,
                )
                body['entries'].clear()
        elif sys.getsizeof(json.dumps(parsed_data[index:index + 100])) + sys.getsizeof(
                json.dumps(body['entries'])) <= 950000:
            body['entries'].extend(parsed_data[index:index + 100])
            index += 100
        else:
            _send_logs_to_chronicle(
                http_session,
                body,
                REGION
            )
            body['entries'].clear()
    if body['entries']:
        _send_logs_to_chronicle(
            http_session,
            body,
            REGION
        )


def _send_logs_to_chronicle(
        http_session: Requests.AuthorizedSession,
        body: list[Any],
        region: str
):
    """Sends unstructured log entries to the Chronicle backend for ingestion.

     Args:
        http_session: Authorized session for HTTP requests.
        body: body containing json to pass data in API call. The total size
            of this string may not exceed 1MB or the resulting request to
            the ingestion API will fail.
        region: Region of Ingestion API's.
    Raises:
      requests.exceptions.HTTPError: HTTP request resulted in an error
      (response.status_code >= 400).
    """

    ingestion_api_base_url = "malachiteingestion-pa.googleapis.com"
    if region != "us":
        url = ("https://" + region.lower() + "-" + ingestion_api_base_url +
               "/v2/unstructuredlogentries:batchCreate")
    else:
        url = ("https://" + ingestion_api_base_url +
               "/v2/unstructuredlogentries:batchCreate")

    header = {"Content-Type": "application/json"}
    print(f"Attempting to push {len(body['entries'])} log(s) to Chronicle.")
    response = http_session.request("POST", url, json=body, headers=header)
    try:
        response.raise_for_status()
        if not response.json():
            print(f"{len(body['entries'])} log(s) pushed successfully to Chronicle.")
    except Exception as err:
        raise RuntimeError(
            f"Error occurred while pushing logs to Chronicle. "
            f"Status code {response.status_code}. Reason: {response.json()}"
        ) from err
